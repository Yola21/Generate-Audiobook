import AWS from "aws-sdk";
import { v4 as uuidv4 } from "uuid";

const S3_BUCKET_NAME = "resume-parser-s3";
const SNS_TOPIC_NAME = "ResumeParserSNS";

const s3 = new AWS.S3();
const textract = new AWS.Textract();
const sns = new AWS.SNS();

const handler = async (event, context) => {
  console.log("Invoking Lambda", event);
  try {
    // Handle CORS preflight request
    if (event.httpMethod === "OPTIONS") {
      return {
        statusCode: 200,
        headers: {
          "Access-Control-Allow-Origin": "http://54.88.124.205/",
          "Access-Control-Allow-Headers": "Content-Type",
          "Access-Control-Allow-Methods": "OPTIONS,POST",
        },
        body: JSON.stringify({ message: "Preflight request successful" }),
      };
    }

    const { resume, email } = JSON.parse(event.body);
    const fileContent = Buffer.from(resume, "base64");

    const params = {
      Bucket: S3_BUCKET_NAME,
      Key: `resumes/${uuidv4()}.pdf`,
      Body: fileContent,
    };

    const result = await s3.upload(params).promise();
    console.log("File uploaded to S3:", result, result.Location);

    const extractedData = await extractTextFromResume(result.Key, email);

    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "http://54.88.124.205/",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        message: "Resume uploaded successfully",
        extractedData,
      }),
    };
  } catch (error) {
    return {
      statusCode: 500,
      headers: {
        "Access-Control-Allow-Origin": "http://54.88.124.205/",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ error: error.message }),
    };
  }
};

async function extractTextFromResume(Key, email) {
  try {
    const params = {
      Bucket: S3_BUCKET_NAME,
      Key: Key,
    };

    const data = await s3.getObject(params).promise();
    const fileContent = data.Body;

    const textractParams = {
      Document: {
        Bytes: fileContent,
      },
      FeatureTypes: ["LAYOUT"],
    };

    const response = await textract.analyzeDocument(textractParams).promise();

    const extractedData = extractInformationFromTextractResponse(response);

    await publishToSnsTopic(extractedData, email);

    return extractedData;
  } catch (error) {
    throw new Error("Error extracting text from resume: " + error.message);
  }
}

function extractInformationFromTextractResponse(response) {
  let name = "";
  let education = "";
  let experience = "";

  response.Blocks.forEach((block) => {
    if (block.BlockType === "LINE") {
      if (!name) {
        name = block.Text;
      }
      if (block.Text.toLowerCase().includes("education")) {
        education = block.Text;
      }
      if (block.Text.toLowerCase().includes("experience")) {
        experience = block.Text;
      }
    }
  });

  return { name, education, experience };
}

async function publishToSnsTopic(extractedData, email) {
  try {
    const snsParams = {
      TopicArn: await getSnsTopicArn(SNS_TOPIC_NAME),
      Message: `Extracted Data: ${JSON.stringify(extractedData)}`,
      Subject: "Resume Extraction Result",
    };

    await sns.publish(snsParams).promise();
  } catch (error) {
    throw new Error("Error publishing message to SNS topic: " + error.message);
  }
}

async function getSnsTopicArn(topicName) {
  try {
    const response = await sns.listTopics().promise();
    const topics = response.Topics || [];
    for (const topic of topics) {
      if (topic.TopicArn.includes(topicName)) {
        return topic.TopicArn;
      }
    }
    return null;
  } catch (error) {
    throw new Error("Error fetching SNS topics: " + error.message);
  }
}

export { handler };
